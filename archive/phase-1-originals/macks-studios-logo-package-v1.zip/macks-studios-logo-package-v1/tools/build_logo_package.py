#!/usr/bin/env python3
"""Build the versioned Macks Studios logo package from the adjusted source mark."""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import zipfile
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFont
from scipy import ndimage


REPO_ROOT = Path(__file__).resolve().parents[1]
PACKAGE_ROOT = REPO_ROOT / "brand" / "macks-studios-logo-package-v1"
DELIVERABLE = REPO_ROOT / "deliverables" / "macks-studios-logo-package-v1.zip"
PUBLIC_ROOT = REPO_ROOT / "public"
DEFAULT_SOURCE = Path(
    "E:/Research/Clients/Macks Studios/_base41/raw/knowledge-loop/"
    "iwo-2d3285a1af41cc94-codex-clipboard-631d2c23-ee54-4d6b-9396-1b727f2dc621.png"
)

SOURCE_SIZE = (1600, 1200)
TIGHT_BBOX = (264, 140, 1336, 1060)
TIGHT_SIZE = (1072, 920)

# Exact geometry recovered from Max's adjusted seven-bar source artwork.
BAR_POLYGONS = [
    [(264, 140), (374, 182), (374, 1060), (264, 1060)],
    [(424, 832), (534, 874), (534, 1060), (424, 1060)],
    [(584, 324), (694, 366), (694, 1060), (584, 1060)],
    [(745, 646), (855, 646), (855, 1060), (745, 1060)],
    [(905, 366), (1015, 324), (1015, 1060), (905, 1060)],
    [(1065, 874), (1175, 832), (1175, 1060), (1065, 1060)],
    [(1225, 182), (1335, 140), (1335, 1060), (1225, 1060)],
]

COLORS = {
    "sage": (124, 152, 133),
    "black": (0, 0, 0),
    "white": (255, 255, 255),
    "dark": (13, 17, 23),
    "light": (244, 243, 239),
}

MARK_SIZES = {
    "1600x1200": (1600, 1200),
    "1024x768": (1024, 768),
    "512x384": (512, 384),
    "256x192": (256, 192),
}
ICON_SIZES = [2048, 1024, 512, 256, 128, 64, 48, 32, 16]


def ensure_dirs() -> None:
    directories = [
        PACKAGE_ROOT / "source",
        PACKAGE_ROOT / "vector" / "mark",
        PACKAGE_ROOT / "vector" / "icon",
        PACKAGE_ROOT / "png" / "transparent" / "mark",
        PACKAGE_ROOT / "png" / "transparent" / "icon",
        PACKAGE_ROOT / "webp",
        PACKAGE_ROOT / "backgrounds",
        PACKAGE_ROOT / "web",
        PACKAGE_ROOT / "print",
        PACKAGE_ROOT / "previews",
        PACKAGE_ROOT / "tools",
        DELIVERABLE.parent,
        PUBLIC_ROOT,
    ]
    for directory in directories:
        directory.mkdir(parents=True, exist_ok=True)


def antialiased_polygon_mask(size: tuple[int, int], polygons: list[list[tuple[int, int]]], scale: int = 4) -> Image.Image:
    large = Image.new("L", (size[0] * scale, size[1] * scale), 0)
    draw = ImageDraw.Draw(large)
    for polygon in polygons:
        scaled = [(round(x * scale), round(y * scale)) for x, y in polygon]
        draw.polygon(scaled, fill=255)
    return large.resize(size, Image.Resampling.LANCZOS)


def extract_clean_transparent_source(source: Image.Image) -> Image.Image:
    """Keep the exact source pixels while replacing contaminated edge pixels."""
    crop = np.array(source.crop(TIGHT_BBOX).convert("RGB"), dtype=np.uint8)
    relative_polygons = [
        [(x - TIGHT_BBOX[0], y - TIGHT_BBOX[1]) for x, y in polygon]
        for polygon in BAR_POLYGONS
    ]
    alpha_image = antialiased_polygon_mask(TIGHT_SIZE, relative_polygons)
    alpha = np.array(alpha_image, dtype=np.uint8)

    background = np.array(source.getpixel((0, 0))[:3], dtype=np.int16)
    distance = np.max(np.abs(crop.astype(np.int16) - background), axis=2)
    reliable = (alpha >= 250) & (distance >= 25)
    if not reliable.any():
        raise RuntimeError("No reliable foreground pixels were found in the source artwork.")

    nearest_indices = ndimage.distance_transform_edt(
        ~reliable,
        return_distances=False,
        return_indices=True,
    )
    nearest_rgb = crop[nearest_indices[0], nearest_indices[1]]
    repaired = crop.copy()
    repair_zone = (alpha > 0) & ~reliable
    repaired[repair_zone] = nearest_rgb[repair_zone]
    repaired[alpha == 0] = 0
    rgba = np.dstack([repaired, alpha])

    tight = Image.fromarray(rgba, "RGBA")
    canvas = Image.new("RGBA", SOURCE_SIZE, (0, 0, 0, 0))
    canvas.alpha_composite(tight, dest=(TIGHT_BBOX[0], TIGHT_BBOX[1]))
    return canvas


def solid_variant(alpha_source: Image.Image, rgb: tuple[int, int, int]) -> Image.Image:
    alpha = alpha_source.getchannel("A")
    color = Image.new("RGBA", alpha_source.size, (*rgb, 255))
    color.putalpha(alpha)
    return color


def resize_rgba(image: Image.Image, size: tuple[int, int]) -> Image.Image:
    """Resize RGBA data in premultiplied-alpha space to prevent dark fringes."""
    if image.size == size:
        return image.copy()
    source = np.asarray(image.convert("RGBA"), dtype=np.float32) / 255.0
    alpha = source[..., 3]
    premultiplied = source[..., :3] * alpha[..., None]

    resized_alpha = np.asarray(
        Image.fromarray(alpha, "F").resize(size, Image.Resampling.LANCZOS),
        dtype=np.float32,
    )
    resized_premultiplied = np.stack(
        [
            np.asarray(
                Image.fromarray(premultiplied[..., channel], "F").resize(
                    size,
                    Image.Resampling.LANCZOS,
                ),
                dtype=np.float32,
            )
            for channel in range(3)
        ],
        axis=2,
    )

    resized_alpha = np.clip(resized_alpha, 0.0, 1.0)
    rgb = np.zeros_like(resized_premultiplied)
    visible = resized_alpha > 1e-6
    rgb[visible] = resized_premultiplied[visible] / resized_alpha[visible, None]
    rgb = np.clip(rgb, 0.0, 1.0)
    result = np.dstack([rgb, resized_alpha])
    return Image.fromarray(np.round(result * 255.0).astype(np.uint8), "RGBA")


def square_icon(mark: Image.Image, size: int, width_ratio: float = 0.56) -> Image.Image:
    tight = mark.crop(mark.getbbox())
    target_width = max(1, round(size * width_ratio))
    target_height = max(1, round(target_width * tight.height / tight.width))
    if target_height > round(size * width_ratio):
        target_height = round(size * width_ratio)
        target_width = max(1, round(target_height * tight.width / tight.height))
    scaled = resize_rgba(tight, (target_width, target_height))
    canvas = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    x = (size - target_width) // 2
    y = (size - target_height) // 2
    canvas.alpha_composite(scaled, dest=(x, y))
    return canvas


def save_png_exports(variants: dict[str, Image.Image]) -> dict[str, dict[int, Path]]:
    square_outputs: dict[str, dict[int, Path]] = {}
    mark_dir = PACKAGE_ROOT / "png" / "transparent" / "mark"
    icon_dir = PACKAGE_ROOT / "png" / "transparent" / "icon"

    for variant, image in variants.items():
        for size_label, size in MARK_SIZES.items():
            output = mark_dir / f"macks-studios-mark-{variant}-{size_label}.png"
            resize_rgba(image, size).save(output, optimize=True)

        square_outputs[variant] = {}
        for size in ICON_SIZES:
            output = icon_dir / f"macks-studios-icon-{variant}-{size}x{size}.png"
            icon = square_icon(image, size, 0.56)
            icon.save(output, optimize=True)
            square_outputs[variant][size] = output

    return square_outputs


def polygon_points(polygon: list[tuple[int, int]]) -> str:
    return " ".join(f"{x},{y}" for x, y in polygon)


def svg_markup(variant: str, square: bool = False, favicon: bool = False) -> str:
    if square:
        view_box = "0 0 512 512"
        ratio = 0.88 if favicon else 0.56
        mark_width = 512 * ratio
        scale = mark_width / TIGHT_SIZE[0]
        mark_height = TIGHT_SIZE[1] * scale
        tx = (512 - mark_width) / 2 - TIGHT_BBOX[0] * scale
        ty = (512 - mark_height) / 2 - TIGHT_BBOX[1] * scale
        transform = f' transform="translate({tx:.4f} {ty:.4f}) scale({scale:.7f})"'
    else:
        view_box = "0 0 1600 1200"
        transform = ""

    defs = ""
    if variant == "color":
        defs = """
  <defs>
    <linearGradient id="sage-left" x1="0" y1="1" x2="1" y2="0">
      <stop offset="0" stop-color="#596f63"/>
      <stop offset="1" stop-color="#a5c1af"/>
    </linearGradient>
    <linearGradient id="sage-center" x1="0" y1="1" x2="0" y2="0">
      <stop offset="0" stop-color="#61786b"/>
      <stop offset="1" stop-color="#a9c6b3"/>
    </linearGradient>
    <linearGradient id="sage-right" x1="1" y1="1" x2="0" y2="0">
      <stop offset="0" stop-color="#596f63"/>
      <stop offset="1" stop-color="#a5c1af"/>
    </linearGradient>
  </defs>"""
        fills = ["url(#sage-left)"] * 3 + ["url(#sage-center)"] + ["url(#sage-right)"] * 3
    else:
        solid = {"sage": "#7c9885", "black": "#000000", "white": "#ffffff"}[variant]
        fills = [solid] * 7

    paths = "\n".join(
        f'    <polygon points="{polygon_points(polygon)}" fill="{fills[index]}"/>'
        for index, polygon in enumerate(BAR_POLYGONS)
    )
    return f"""<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="{view_box}" role="img" aria-labelledby="title desc">
  <title id="title">Macks Studios mark</title>
  <desc id="desc">Seven vertical bars with mirrored angled tops arranged as a symmetrical studio mark.</desc>{defs}
  <g{transform}>
{paths}
  </g>
</svg>
"""


def save_vector_exports() -> None:
    for variant in ["color", "sage", "black", "white"]:
        (PACKAGE_ROOT / "vector" / "mark" / f"macks-studios-mark-{variant}.svg").write_text(
            svg_markup(variant, square=False),
            encoding="utf-8",
        )
        (PACKAGE_ROOT / "vector" / "icon" / f"macks-studios-icon-{variant}.svg").write_text(
            svg_markup(variant, square=True),
            encoding="utf-8",
        )


def place_on_background(mark: Image.Image, background: tuple[int, int, int], size: int = 2048, ratio: float = 0.56) -> Image.Image:
    foreground = square_icon(mark, size, ratio)
    canvas = Image.new("RGBA", (size, size), (*background, 255))
    canvas.alpha_composite(foreground)
    return canvas.convert("RGB")


def save_background_exports(variants: dict[str, Image.Image]) -> None:
    combinations = [
        ("color-on-dark", variants["color"], COLORS["dark"]),
        ("white-on-dark", variants["white"], COLORS["dark"]),
        ("color-on-light", variants["color"], COLORS["light"]),
        ("black-on-light", variants["black"], COLORS["light"]),
    ]
    for label, mark, background in combinations:
        master = place_on_background(mark, background)
        for size in [2048, 1024, 512]:
            image = master if size == 2048 else master.resize((size, size), Image.Resampling.LANCZOS)
            png = PACKAGE_ROOT / "backgrounds" / f"macks-studios-{label}-{size}x{size}.png"
            jpg = PACKAGE_ROOT / "backgrounds" / f"macks-studios-{label}-{size}x{size}.jpg"
            image.save(png, optimize=True)
            image.save(jpg, quality=94, optimize=True)


def save_webp_exports(variants: dict[str, Image.Image]) -> None:
    for variant, mark in variants.items():
        mark_output = PACKAGE_ROOT / "webp" / f"macks-studios-mark-{variant}-1024x768.webp"
        icon_output = PACKAGE_ROOT / "webp" / f"macks-studios-icon-{variant}-512x512.webp"
        resize_rgba(mark, (1024, 768)).save(mark_output, format="WEBP", lossless=True, method=6)
        square_icon(mark, 512, 0.56).save(icon_output, format="WEBP", lossless=True, method=6)


def save_web_exports(variants: dict[str, Image.Image]) -> None:
    web_dir = PACKAGE_ROOT / "web"
    for variant in ["color", "black", "white"]:
        (web_dir / f"favicon-{variant}.svg").write_text(
            svg_markup(variant, square=True, favicon=True),
            encoding="utf-8",
        )
    shutil.copy2(web_dir / "favicon-color.svg", web_dir / "favicon.svg")

    for size in [16, 32, 48]:
        square_icon(variants["color"], size, 0.88).save(
            web_dir / f"favicon-{size}x{size}.png",
            optimize=True,
        )
    ico_master = square_icon(variants["color"], 256, 0.88)
    ico_master.save(web_dir / "favicon.ico", format="ICO", sizes=[(16, 16), (32, 32), (48, 48)])

    square_icon(variants["color"], 192, 0.72).save(web_dir / "icon-192x192.png", optimize=True)
    square_icon(variants["color"], 512, 0.72).save(web_dir / "icon-512x512.png", optimize=True)

    apple = Image.new("RGBA", (180, 180), (*COLORS["dark"], 255))
    apple.alpha_composite(square_icon(variants["color"], 180, 0.66))
    apple.convert("RGB").save(web_dir / "apple-touch-icon.png", optimize=True)

    for size in [512, 1024]:
        maskable = Image.new("RGBA", (size, size), (*COLORS["dark"], 255))
        maskable.alpha_composite(square_icon(variants["color"], size, 0.56))
        maskable.convert("RGB").save(web_dir / f"icon-maskable-{size}x{size}.png", optimize=True)


def save_print_exports() -> list[str]:
    warnings: list[str] = []
    try:
        from reportlab.graphics import renderPDF, renderPS
        from reportlab.graphics.shapes import Drawing, Polygon, Rect
        from reportlab.lib.colors import Color
    except ImportError:
        warnings.append("ReportLab unavailable: PDF and EPS exports were skipped.")
        return warnings

    variants = {
        "sage": (COLORS["sage"], None),
        "black": (COLORS["black"], None),
        "white-on-dark": (COLORS["white"], COLORS["dark"]),
    }
    for label, (foreground, background) in variants.items():
        drawing = Drawing(SOURCE_SIZE[0], SOURCE_SIZE[1])
        if background is not None:
            drawing.add(
                Rect(
                    0,
                    0,
                    SOURCE_SIZE[0],
                    SOURCE_SIZE[1],
                    fillColor=Color(*(channel / 255 for channel in background)),
                    strokeColor=None,
                )
            )
        color = Color(*(channel / 255 for channel in foreground))
        for polygon in BAR_POLYGONS:
            flattened: list[float] = []
            for x, y in polygon:
                flattened.extend([x, SOURCE_SIZE[1] - y])
            drawing.add(Polygon(flattened, fillColor=color, strokeColor=None))
        renderPDF.drawToFile(drawing, str(PACKAGE_ROOT / "print" / f"macks-studios-mark-{label}.pdf"))
        renderPS.drawToFile(drawing, str(PACKAGE_ROOT / "print" / f"macks-studios-mark-{label}.eps"))
    return warnings


def get_font(size: int) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
    candidates = [
        Path(r"C:\Windows\Fonts\segoeui.ttf"),
        Path(r"C:\Windows\Fonts\arial.ttf"),
    ]
    for candidate in candidates:
        if candidate.exists():
            return ImageFont.truetype(str(candidate), size=size)
    return ImageFont.load_default()


def draw_centered_text(draw: ImageDraw.ImageDraw, box: tuple[int, int, int, int], text: str, font: ImageFont.ImageFont, fill: tuple[int, int, int]) -> None:
    bounds = draw.textbbox((0, 0), text, font=font)
    width = bounds[2] - bounds[0]
    height = bounds[3] - bounds[1]
    x = box[0] + (box[2] - box[0] - width) // 2
    y = box[1] + (box[3] - box[1] - height) // 2
    draw.text((x, y), text, font=font, fill=fill)


def save_previews(variants: dict[str, Image.Image]) -> None:
    preview_dir = PACKAGE_ROOT / "previews"
    panel_size = 800
    contact = Image.new("RGB", (panel_size * 2, panel_size * 2), COLORS["light"])
    panels = [
        (0, 0, variants["color"], COLORS["dark"], "COLOR | DARK"),
        (panel_size, 0, variants["white"], COLORS["dark"], "WHITE | DARK"),
        (0, panel_size, variants["color"], COLORS["light"], "COLOR | LIGHT"),
        (panel_size, panel_size, variants["black"], COLORS["light"], "BLACK | LIGHT"),
    ]
    font = get_font(28)
    for x, y, mark, background, label in panels:
        panel = place_on_background(mark, background, panel_size, 0.56)
        contact.paste(panel, (x, y))
        draw = ImageDraw.Draw(contact)
        text_fill = COLORS["white"] if background == COLORS["dark"] else COLORS["black"]
        draw_centered_text(draw, (x, y + panel_size - 72, x + panel_size, y + panel_size), label, font, text_fill)
    contact.save(preview_dir / "logo-package-contact-sheet.png", optimize=True)
    contact.save(preview_dir / "logo-package-contact-sheet.jpg", quality=94, optimize=True)

    checker = Image.new("RGB", (1200, 1200), (255, 255, 255))
    checker_draw = ImageDraw.Draw(checker)
    cell = 60
    for y in range(0, 1200, cell):
        for x in range(0, 1200, cell):
            shade = (218, 220, 222) if (x // cell + y // cell) % 2 else (247, 247, 247)
            checker_draw.rectangle((x, y, x + cell - 1, y + cell - 1), fill=shade)
    checker = checker.convert("RGBA")
    checker.alpha_composite(square_icon(variants["color"], 1200, 0.56))
    checker.convert("RGB").save(preview_dir / "transparency-checkerboard-preview.png", optimize=True)

    circle_preview = Image.new("RGB", (1600, 800), (37, 41, 47))
    for index, background in enumerate([COLORS["dark"], COLORS["light"]]):
        tile = place_on_background(variants["color"], background, 680, 0.56)
        circle_mask = Image.new("L", (680, 680), 0)
        ImageDraw.Draw(circle_mask).ellipse((0, 0, 679, 679), fill=255)
        x = 60 + index * 800
        circle_preview.paste(tile, (x, 60), circle_mask)
    circle_preview.save(preview_dir / "circle-crop-preview.png", optimize=True)


def write_generated_templates() -> None:
    manifest_template = {
        "name": "Macks Studios",
        "short_name": "Macks Studios",
        "icons": [
            {"src": "/brand/icon-192x192.png", "sizes": "192x192", "type": "image/png", "purpose": "any"},
            {"src": "/brand/icon-512x512.png", "sizes": "512x512", "type": "image/png", "purpose": "any"},
            {"src": "/brand/icon-maskable-512x512.png", "sizes": "512x512", "type": "image/png", "purpose": "maskable"},
        ],
        "theme_color": "#0D1117",
        "background_color": "#0D1117",
        "display": "standalone",
    }
    (PACKAGE_ROOT / "web" / "site.webmanifest.template.json").write_text(
        json.dumps(manifest_template, indent=2) + "\n",
        encoding="utf-8",
    )
    head_links = """<!-- Copy the files to your public asset directory and adjust paths as needed. -->
<link rel="icon" href="/brand/favicon.svg" type="image/svg+xml">
<link rel="icon" href="/brand/favicon-32x32.png" sizes="32x32" type="image/png">
<link rel="icon" href="/brand/favicon-16x16.png" sizes="16x16" type="image/png">
<link rel="icon" href="/brand/favicon.ico" sizes="any">
<link rel="apple-touch-icon" href="/brand/apple-touch-icon.png" sizes="180x180">
<link rel="manifest" href="/site.webmanifest">
"""
    (PACKAGE_ROOT / "web" / "head-links.html").write_text(head_links, encoding="utf-8")


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def build_asset_manifest(warnings: list[str]) -> dict[str, object]:
    entries: list[dict[str, object]] = []
    for path in sorted(PACKAGE_ROOT.rglob("*")):
        if not path.is_file() or path.name == "asset-manifest.json":
            continue
        entry: dict[str, object] = {
            "path": path.relative_to(PACKAGE_ROOT).as_posix(),
            "bytes": path.stat().st_size,
            "sha256": file_sha256(path),
        }
        if path.suffix.lower() in {".png", ".jpg", ".jpeg", ".webp", ".ico"}:
            try:
                with Image.open(path) as image:
                    entry["width"] = image.width
                    entry["height"] = image.height
                    entry["mode"] = image.mode
                    entry["format"] = image.format
            except OSError:
                pass
        entries.append(entry)
    return {
        "package": "Macks Studios Logo Package",
        "version": "1.0.0",
        "source_sha256": file_sha256(DEFAULT_SOURCE) if DEFAULT_SOURCE.exists() else None,
        "generated_files": len(entries),
        "warnings": warnings,
        "assets": entries,
    }


def write_zip() -> None:
    with zipfile.ZipFile(DELIVERABLE, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(PACKAGE_ROOT.rglob("*")):
            if path.is_file():
                archive.write(path, Path(PACKAGE_ROOT.name) / path.relative_to(PACKAGE_ROOT))


def build(source_path: Path) -> dict[str, object]:
    ensure_dirs()
    if not source_path.exists():
        raise FileNotFoundError(f"Source artwork not found: {source_path}")

    source = Image.open(source_path).convert("RGB")
    if source.size != SOURCE_SIZE:
        raise ValueError(f"Expected source size {SOURCE_SIZE}, received {source.size}.")

    shutil.copy2(source_path, PACKAGE_ROOT / "source" / "macks-studios-mark-source-adjusted.png")
    shutil.copy2(Path(__file__), PACKAGE_ROOT / "tools" / Path(__file__).name)

    color = extract_clean_transparent_source(source)
    variants = {
        "color": color,
        "sage": solid_variant(color, COLORS["sage"]),
        "black": solid_variant(color, COLORS["black"]),
        "white": solid_variant(color, COLORS["white"]),
    }

    square_outputs = save_png_exports(variants)
    save_vector_exports()
    save_background_exports(variants)
    save_webp_exports(variants)
    save_web_exports(variants)
    warnings = save_print_exports()
    save_previews(variants)
    write_generated_templates()

    resize_rgba(color, SOURCE_SIZE).save(PUBLIC_ROOT / "macks-studios-logo-transparent.png", optimize=True)
    shutil.copy2(
        square_outputs["color"][1024],
        PUBLIC_ROOT / "macks-studios-icon-transparent.png",
    )

    manifest = build_asset_manifest(warnings)
    (PACKAGE_ROOT / "asset-manifest.json").write_text(
        json.dumps(manifest, indent=2) + "\n",
        encoding="utf-8",
    )
    write_zip()

    return {
        "package_root": str(PACKAGE_ROOT),
        "zip": str(DELIVERABLE),
        "generated_files": manifest["generated_files"],
        "public_logo": str(PUBLIC_ROOT / "macks-studios-logo-transparent.png"),
        "public_icon": str(PUBLIC_ROOT / "macks-studios-icon-transparent.png"),
        "warnings": warnings,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, default=DEFAULT_SOURCE)
    args = parser.parse_args()
    result = build(args.source.resolve())
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
