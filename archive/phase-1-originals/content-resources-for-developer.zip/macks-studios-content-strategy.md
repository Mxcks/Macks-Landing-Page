---
id: macks-studios-content-strategy
name: Macks Studios Content Strategy
type: doc
source: Maren-authored strategy doc, grounded in Max's confirmed channels and voice rules (2026-09-22)
confidence: strong
last_verified: 2026-09-22
---

# Macks Studios Content Strategy

The applied layer: how Macks Studios actually produces posting content, landing pages, email, and proposals. The universal frameworks live in `frameworks/content/`; this file says which ones we use, where, and under what rules.

## The job content is hired to do

Content has one job: turn strangers into diagnostic bookings. Every piece is scored against that. Anything that does not serve pipeline, positioning, or proof is cut (see frameworks/content/content-pillars.md: pillars are a decision device, not just an organizer).

## Channels and their rules

### Instagram: @macksstudiosorg
- Brand: Macks Studios directly. No side brands; all traffic builds the business brand and funnels into kits plus done-for-you services.
- Faceless format. Short-form video follows frameworks/content/hook-value-cta.md: hook in the first 2-3 seconds, one transformation per video, one micro-CTA.
- Copy under posts follows frameworks/content/pas.md where the audience is problem-aware; gain-framing where aspiration converts better.

### Reddit: u/Outside_Castle
- Voice: plainspoken and human, never AI-sounding. One idea per comment, story-first, never an instruction-overloaded how-to.
- Every comment carries its own context; never rely on the thread title.
- First-person as Macks Studios. Never use Max's real name.
- PAS applies in miniature: name the reader's pain accurately, then the way out.

### Landing pages (macksstudios.org, maxstern.org)
- Every page follows frameworks/content/landing-page-anatomy.md: one page, one goal, one CTA; headline matches the ad or link that sent the visitor.
- Campaign planning runs through frameworks/content/aida.md: what to communicate at each stage, which message on which surface.
- Copy length follows offer complexity, not taste. Nothing ships untested where a test is cheap.

### Email sequences
- PAS for problem-aware segments; AIDA to plan what each email in a sequence is hired to do.
- Every sequence ends in one action: book the diagnostic.

### Proposals and diagnostics
- Landing-page anatomy disciplines the proposal: one goal (signed yes), proof before price, objection handling before the ask, risk reversal before the final CTA.
- AIDA audits the diagnostic narrative: are we building desire or jumping from interest to action?

## Content pillars (Macks Studios)

Written as promises to a specific reader:

1. **Your business runs on systems you cannot see.** For service-business owners losing money to invisible admin drag: the seven systems, the 90/10 admin-to-design split, the uninvoiced-work leak.
2. **Build once, sell repeatedly.** For builders and operators: productized offers, reusable systems, why bespoke work does not scale.
3. **Proof over promises.** Behind-the-scenes of real builds, real numbers, real client outcomes. Specific and named where permission exists.
4. **The operator's notebook.** How Maren and Max actually run the business: constraint-first decisions, kill criteria, attention discipline. This pillar recruits collaborators and signals how it feels to work with us.

Selection tests (demand, authority, business goal) all pass: the audience asks for this, we live it, and every pillar ladders to diagnostic bookings.

## The repurposing workflow

Solo-operator economics: one pillar asset per week becomes the week's content (see frameworks/content/content-repurposing.md).

1. One long-form source per week: a build session, a client finding, a strategy note.
2. Atomize into platform-contextual derivatives: 2-3 shorts (hook-value-CTA), one Reddit story, one email, quote cards.
3. Each derivative links back toward the diagnostic or the relevant landing page.
4. Quality gate before re-release: facts current, angle suited to the channel. No identical cross-posting.

## SEO (later, not now)

frameworks/content/topic-clusters.md is filed and ready for when the sites earn search investment. Until pipeline is the constraint, search is not the channel. Do not build clusters before the offer pages they would point to exist.

## Voice rules (standing)

- Plainspoken, direct, warm with an edge. No filler, no sycophancy, no em dashes.
- Score every outward-facing word against positioning.md before it ships.
- Nothing public without Max's explicit greenlight. Drafts shown first, always.

## Review

Quarterly: which pillar drove bookings, which formats get cut. Any pillar with no attributable pipeline after two quarters is replaced, not kept out of sentimentality.
