# Content resources for Macks Studios

A small package of the content frameworks and strategy from the private strategy repo.

## What's inside

- `content-frameworks-hub.html` - open in a browser. All 7 frameworks as cards, each opening into a full cheat sheet. Start here.
- `frameworks/` - the 7 framework files (markdown): content-pillars, topic-clusters, hook-value-cta, aida, pas, landing-page-anatomy, content-repurposing.
- `macks-studios-content-strategy.md` - how Macks Studios actually does content: channels, pillars, the weekly repurposing routine, voice rules.

## Status note

The 7 frameworks are reference material (researched 2026-09-22), not the backbone. The backbone is Max's seven business systems; the per-system content playbooks are still being defined.
