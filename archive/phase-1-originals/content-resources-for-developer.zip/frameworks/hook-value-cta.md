---
id: hook-value-cta
name: Hook-Value-CTA
type: pattern
source: Industry practice from short-form creator and ad culture; no single originator (practitioner sources: Reelrise, Scriptstorm)
confidence: moderate
last_verified: 2026-09-22
version: 1.0
situations: [posting-content, short-form-video]
aliases: [hook-body-cta, hook-body-payoff]
used_by: [posting-content]
updated_by_run:
---

# Hook-Value-CTA

## Summary
A three-beat composition pattern for short-form video scripts, not a decision model. The hook stops the scroll in the first 2-3 seconds, the value section delivers the promised payoff, and a micro-CTA closes with one specific next action. The pattern maps to what short-video algorithms reward: early watch time, average view duration, completion rate, replays.

## When to use
When scripting TikToks, Reels, or Shorts for a creator or brand that opens videos with long intros. When testing creative at volume: its repeatable-template quality is the point (several shorts per week, test hooks weekly).

## How to apply
1. Hook (first 2-3 seconds): promise a payoff and clarify who the video is for. Patterns: big promise, contrarian claim, open loop, pattern interrupt, numbers, challenge, before/after. Answer "why should I keep watching?"
2. Value (the middle): deliver on the hook's promise fast. One transformation per video: teach one tactic, show one workflow, reveal one mistake. Anchor steps with on-screen text; be concise.
3. CTA (the close): one specific, actionable micro-ask (comment a word, save, follow for the topic, watch part 2). Keep it light and placed over the final visual; hard sells hurt watch time.
4. Treat the contract as binding: the hook makes a promise, the value keeps it. Bait-and-switch trains the audience to scroll past you.

## Pitfalls
- Treating it as a viral guarantee; "every viral video follows a structure" is vendor marketing, not established evidence.
- Bait-and-switch: the hook promises a payoff the value section never delivers.
- Heavy CTAs that kill retention.
- Label drift across the team: Hook-Body-CTA, Hook-Value-CTA, and Hook-Body-Payoff all circulate; agree which beats you mean.

## Sources
- Reelrise, "The Hook-Value-CTA Formula: Scripting Videos That Convert" (https://reelrise.app/guide/the-hook-value-cta-formula-scripting-videos-that-convert/)
- Scriptstorm, "YouTube Shorts Scripts: Hook-Value-CTA Formula Blueprint" (https://scriptstorm.ai/blog/youtube-shorts-scripts-hook-value-cta-formula-blueprint)
