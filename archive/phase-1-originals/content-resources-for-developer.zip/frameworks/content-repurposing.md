---
id: content-repurposing
name: Content Repurposing
type: framework
source: Industry practice; popularized and named as a marketing workflow by Gary Vaynerchuk (2019 content-model post). Note: the phrase "create once, publish everywhere" belongs to NPR's COPE structured-content engineering (2009) and is a different concept.
confidence: moderate
last_verified: 2026-09-22
version: 1.0
situations: [posting-content, channel-expansion, asset-reuse]
aliases: [reverse pyramid, atomization]
used_by: [posting-content, outreach]
updated_by_run:
---

# Content Repurposing

## Summary
One high-investment "pillar" asset is atomized into many smaller, platform-contextual pieces of content, with the micro pieces driving attention back to the original. It trades scarce creation time for adaptation time: the right move for a solo operator or small team whose output demand exceeds production capacity.

## When to use
A high-cost asset (keynote, webinar, research report) that underperformed on reach. Entering new channels and needing a back-catalog of native-feeling content fast. An SEO or topic-authority push: multiple derivative pieces around one theme signal topic authority.

## How to apply
1. Start with the pillar asset: one substantial long-form piece (video, keynote, webinar, whitepaper, research report) as the source of truth. Long-form is the best repurposing source because of its information density.
2. Atomize: break the pillar into standalone derivatives: clips, quote cards, infographics, short posts, articles, email sequences. One keynote can yield 30+ pieces.
3. Adapt to each platform's norms; never cross-post identically. Do not repurpose everything everywhere. Refresh facts and statistics and find a new angle for the new audience.
4. Link back: micro content exists partly to drive awareness to the pillar asset.
5. Run the quality gate before each re-release: facts current, messaging intact, angle suited to the new audience. This discipline is what separates the framework from lazy reposting.

## Pitfalls
- Lazy cross-posting: identical copy on every channel violates the platform-contextuality requirement and turns "create once" into spam.
- Quality decay across generations of derivatives; message dilution as the original intent drifts.
- Oversaturation and repetition without a plan, plus duplicate-content SEO harm when derivatives are too similar.
- Republishing stale material: failing to update facts, stats, and angle for the new audience.

## Sources
- Gary Vaynerchuk, "The GaryVee Content Strategy" (https://garyvaynerchuk.com/the-garyvee-content-strategy-how-to-grow-and-distribute-your-brands-social-media-content/)
- ON24, "What Is Content Repurposing (And Does It Work?)" (https://www.on24.com/guides/what-is-content-repurposing-does-it-work/)
- Lullabot, "Understanding Create Once, Publish Everywhere (COPE)" (https://www.lullabot.com/articles/understanding-create-once-publish-everywhere-cope)
