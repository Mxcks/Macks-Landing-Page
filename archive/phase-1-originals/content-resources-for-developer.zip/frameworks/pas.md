---
id: pas
name: PAS (Problem, Agitate, Solve)
type: framework
source: Anonymous direct-response copywriting practice; commonly attributed in industry lore to Dan Kennedy, unverified
confidence: moderate
last_verified: 2026-09-22
version: 1.0
situations: [posting-content, landing-pages, email, ads]
aliases: [paso]
used_by: [posting-content, landing-pages, email, outreach]
updated_by_run:
---

# PAS (Problem, Agitate, Solve)

## Summary
A copywriting formula that hooks the reader by naming their problem, intensifying the pain of it, then presenting the solution. It runs on pain avoidance: the pain-pleasure principle and loss aversion (Kahneman and Tversky's Prospect Theory, 1979). Avoiding loss motivates more than gaining pleasure, so making the cost of inaction vivid moves a problem-aware reader to listen.

## When to use
Short-form copy where attention is scarce: social posts, ads, email openers. Problem-aware audiences who need the cost of inaction made vivid before they will hear a pitch. Story-structured content (video, landing page sections, captions) where empathy and connection are the goal. Landing page sections targeting skeptical audiences.

## How to apply
1. Problem: identify one vivid pain point the audience already feels. Describe it so accurately the reader feels heard: tap the conversation already going on in their head.
2. Agitate: make the pain emotional and specific; spell out the cost of inaction. Discipline matters: never let the reader wallow; always point toward a way out. Agitation needs craft, not volume.
3. Solve: reveal the offering as the balm, the way out.
4. Optional extension, PASO: add Outcome plus proof. Paint the post-purchase transformation and back it with testimonials.
5. Remember formulas are the studwork behind the walls, not the villa: fill-in-the-blanks execution without craft fails.

## Pitfalls
- Over-agitation: agitating past credibility turns the copy cringey and manipulative.
- Using PAS on unaware audiences who do not yet feel the problem; it only works when the pain is recognized.
- Using it where gain-framing (desire, aspiration) would convert better; not every audience is pain-driven.

## Sources
- Copywrite Matters, "The PASO Copywriting Formula" (https://www.copywritematters.com/paso-copywriting-formula/)
- Nonprofit Copywriter, "The PAS Copywriting Formula" (http://www.nonprofitcopywriter.com/PAS-copywriting-formula.html)
- Storyprompt, "Problem-Agitate-Solution: The PAS Storytelling Framework" (https://www.storyprompt.com/blog/problem-agitate-solution-the-pas-storytelling-framework)
