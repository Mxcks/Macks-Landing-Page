---
id: aida
name: AIDA
type: framework
source: Attributed to E. St. Elmo Lewis; the acronym coined by C. P. Russell (Printers' Ink, 1921). Evolved gradually through early-1900s advertising literature.
confidence: strong
last_verified: 2026-09-22
version: 1.0
situations: [campaign-planning, funnel-audit, landing-pages]
aliases: [hierarchy of effects]
used_by: [landing-pages, outreach, proposals]
updated_by_run:
---

# AIDA

## Summary
A hierarchy-of-effects model describing the stages a buyer moves through: Attention (or Awareness), Interest, Desire, Action. It is a communications planning lens, not a decision-making model and not a page-writing template: it tells you what to communicate and when, at each stage of the customer journey. The underlying spine shared by all hierarchy-of-effects models is Cognition -> Affect -> Behaviour (learn, feel, do).

## When to use
Planning a campaign: which messages and platforms per stage. Auditing a funnel for coverage gaps (awareness strong, nothing building desire). Explaining purchase-funnel drop-off to a client or a junior marketer.

## How to apply
1. Attention: create awareness of or affiliation with the offering.
2. Interest: generate interest in the benefits, enough to trigger further research.
3. Desire: build the emotional connection that moves the buyer from "liking" to "wanting."
4. Action: move the buyer to the next step (download, call, buy, subscribe).
5. Map each stage to concrete messages and channels before writing a word of copy.
6. Variants add stages where the business needs them: AIDAR (Retention), AIDAS (Satisfaction).

## Pitfalls
- Treating it as a literal linear buyer journey. Consumers process promotional information through cognitive and affective pathways simultaneously; the empirical literature found hierarchical models poor predictors of actual behavior.
- No post-purchase stage: it ignores satisfaction, repeat patronage, and referrals unless extended.
- Using it as a page-writing template when it is a planning lens: AIDA tells you what to communicate when, not how to structure page sections (see landing-page-anatomy for structure).

## Sources
- Wikipedia, "AIDA (marketing)" (https://en.wikipedia.org/wiki/AIDA_(marketing))
- Smart Insights, "AIDA model" (updated April 2025) (https://www.smartinsights.com/traffic-building-strategy/offer-and-message-development/aida-model/)
