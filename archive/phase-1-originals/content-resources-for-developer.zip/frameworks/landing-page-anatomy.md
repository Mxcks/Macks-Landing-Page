---
id: landing-page-anatomy
name: Landing Page Anatomy
type: framework
source: Industry practice; no single originator (practitioner consensus: Unbounce, CXL, Attn Agency)
confidence: moderate
last_verified: 2026-09-22
version: 1.0
situations: [landing-pages, page-audit, pre-build-review]
aliases: []
used_by: [landing-pages, proposals]
updated_by_run:
---

# Landing Page Anatomy

## Summary
The canonical inventory of what a landing page must contain, plus the conventional section order: hero -> problem agitation -> solution introduction -> features and benefits -> social proof -> objection handling -> guarantee/risk reversal -> final CTA. The durable part is the element inventory and the discipline (one page, one goal); the exact section sequence is convention and should be tested per audience.

## When to use
Building or auditing any lead-gen or sales landing page. Reviewing designer or developer work before build ("draw it on paper; write the copy first"). Deciding copy length by offer complexity rather than taste. Choosing what to A/B test.

## How to apply
1. USP as the main headline, with a supporting headline; the headline must match the ad's message.
2. Hero image or video showing context of use; real people beat goofy stock.
3. Benefits-led copy with supporting features: lead with the benefit, show the feature.
4. Social proof: specific, real names and photos, prospect-identifiable. It cannot be faked.
5. Single conversion goal: one page, one action, one CTA. Conversational button text, short forms with privacy reassurance, CTA repeated at the bottom on long pages.
6. Canonical long-form order: hero -> problem agitation -> solution introduction -> features and benefits -> social proof -> objection handling (FAQ) -> guarantee/risk reversal -> final CTA (restated benefit plus urgency).
7. Process rules: never send ad traffic to a homepage; remove navigation and all off-goal links; clarity trumps persuasion; copy length follows offer complexity (short for free/cheap/low-risk, long for complex/high-consideration); nothing is finished until A/B tested.

## Pitfalls
- Treating the anatomy as a fill-in-the-blanks template; best practices are a starting point, not copy-paste.
- Multiple goals or CTAs on one page ("or else it ain't a landing page").
- Navigation menus, unrelated links, and distracting imagery bleeding conversions.
- Short copy for complex, high-consideration offers; longer, proof-rich copy wins there when each section earns its place.
- Fake or generic testimonials; a headline that does not match the ad's promise; skipping risk reversal before the final CTA.

## Sources
- Unbounce, "The Anatomy of a Landing Page" (https://unbounce.com/landing-page-articles/the-anatomy-of-a-landing-page/)
- CXL, "How to Build a High-Converting Landing Page" (https://cxl.com/blog/how-to-build-a-high-converting-landing-page/)
- Attn Agency, "High-Converting Landing Page Anatomy" (https://www.attnagency.com/blog/high-converting-landing-page-anatomy)
