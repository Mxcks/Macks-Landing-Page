---
id: topic-clusters
name: Topic Clusters (Pillar-and-Cluster)
type: framework
source: HubSpot (Mimi An et al.; building on Anum Hussain and Cambria Davies' 2015 "Topics Over Keywords" research)
confidence: strong
last_verified: 2026-09-22
version: 1.0
situations: [seo, site-architecture, answer-engine-visibility]
aliases: [pillar pages, pillar-and-cluster, hub and spoke]
used_by: [posting-content, landing-pages]
updated_by_run:
---

# Topic Clusters (Pillar-and-Cluster)

## Summary
An SEO content architecture that organizes related pages into a hub-and-spoke structure: one broad pillar page surrounded by focused cluster pages on subtopics, all connected by internal links. The network signals topical authority to search crawlers and to answer engines (ChatGPT, Perplexity, Google AI Overviews), which cite trusted, well-structured sources.

## When to use
When a site has many posts competing for the same keywords (self-cannibalization). When moving from fragmented keyword targeting to topic-level ownership. When the business needs to be the cited source in its category.

## How to apply
1. Choose 3-5 core topics, broad enough to support 20-30 supporting articles each.
2. Validate with keyword research, matched to real search intent per subtopic.
3. Write the pillar page: comprehensive and high-level, targeting the broad head term. Answer "what is X?" in the first paragraphs; let the H2s reflect the cluster's major themes. Write it after finalizing subtopics, not before.
4. Build cluster pages: each covers one subtopic in depth, targets one long-tail keyword or question, and links back to the pillar with descriptive anchor text.
5. Wire the internal link graph: pillar links out to every cluster page, every cluster page links back, cross-links between clusters where relevant. The links are the mechanism, not decoration; SERP gains tracked internal-link density in the original research.
6. Strengthen cluster pages with E-E-A-T signals: author bios, real data, visible update dates.

## Pitfalls
- Confusing the SEO pillar page with a strategic content pillar (see content-pillars): "if you're trying to rank it for a long-tail keyword, it's not a pillar page."
- Keyword cannibalization: two cluster pages targeting the same query split authority between your own pages.
- Building a cluster nobody can credibly own: topics must map to real business expertise, not just search volume.
- Skipping the internal linking, which is the whole mechanism.

## Sources
- HubSpot, "Topic Clusters: The Next Evolution of Content Strategy" (https://blog.hubspot.com/marketing/topic-clusters-seo)
